package f76goat.sftp;

import f76goat.sftp.server.ServerStart;

public class ServerApp {

    public static void run(String[] args) {
        ServerStart.main(args);
    }
}
